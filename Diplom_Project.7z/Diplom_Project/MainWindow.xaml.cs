﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

using Diplom_Project.Entities;

namespace Diplom_Project
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SqlConnection conn;
        public int LoginGroup = 4;//1 - админ, 2 - менеджер, 3 - клиент, 4 - гость
        public string  IDLogin="";
        public MainWindow()
        {
            InitializeComponent();

            string connectionString = "Data Source=DESKTOP-BO3FJ1E\\SQLEXPRESS;Initial Catalog=logistic_services;Integrated Security=true";
            login Log = new login();
            conn = new SqlConnection(connectionString);
            conn.Open();
            //Формирование грида предзаказ
            SqlDataAdapter adapter = new SqlDataAdapter("SELECT TOP(1000)[id_PreOrder],[Start_location],[End_location],[Order_date],[End_date],[weight],[dimensions],[id_login]FROM[logistic_services].[dbo].[PreOrder_2]", conn);
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            PreOrder_grid.ItemsSource = ds.Tables[0].DefaultView;
            //dataGrid.Columns["name"].Visibility = Visibility.Hidden;
            // PreOrder_grid.Columns[0].Visibility = Visibility.Hidden;

            //окончание оформлениягрида па предзаказ

            SqlDataAdapter adapterorder = new SqlDataAdapter(
                "SELECT p.FIO as manager,people.FIO " +
                "as client,[start_location],[ends_location],[distance],[order_date],[finish_date]," +
                "[loaders],[price],[cost],[weight],[dimensions], " +
                "ExAuto.gos_number, cargo.cargo_name, auto.model, auto.stamp " +
                "FROM [logistic_services].[dbo].[orders] o   " +
                "join ExAuto on (o.id_exauto=ExAuto.id_exauto)   " +
                "join cargo on (o.id_cargo = cargo.id_cargo)   " +
                "join client on (client.id_clients=o.id_client) " +
                "join people on (client.id_contact_person=people.id_people)   " +
                "join staff on (staff.id_staff = o.id_manager)   " +
                "join people p on (staff.id_people=p.id_people) " +
                "join auto on (ExAuto.id_auto = auto.id_auto)", conn);
            DataSet dsorder = new DataSet();
            adapterorder.Fill(dsorder);
            ReadyOrder.ItemsSource = dsorder.Tables[0].DefaultView;

            SqlDataAdapter preorder2ndpage = new SqlDataAdapter("SELECT TOP(1000)[id_PreOrder],[Start_location],[End_location],[Order_date],[End_date],[weight],[dimensions],[id_login]FROM[logistic_services].[dbo].[PreOrder_2]", conn);
            DataSet dspreorder2 = new DataSet();
            preorder2ndpage.Fill(dspreorder2);
            StatusOrder_grid.ItemsSource = dspreorder2.Tables[0].DefaultView;
           // StatusOrder_grid.Columns[0].Visibility= Visibility.Hidden;

            if (Log.ShowDialog() == true )
            {
                IDLogin = Log.IDLogin;
                if (Log.user_group == "1")
                {
                   
                }
                if (Log.user_group == "2")
                {
                   

                }
                if (Log.user_group == "3")
                {
                   
                }
                if (Log.user_group == "4")
                {
                   
                }
            }
            else
            {
                Close();
            }
            
        }

        private void add_Click(object sender, RoutedEventArgs e)
        {

        }

        private void update_Click(object sender, RoutedEventArgs e)
        {

        }

        private void PreOrder_grid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
        private string GetnextID(string ID,string TableName)
        {
            string s = "Select max(" + ID + ") from " + TableName;
            SqlCommand command = new SqlCommand("Select max(" + ID + ") "+ID+" from " + TableName, conn);
            r.AppendText("\nSelect max(" + ID + ") " + ID + " from " + TableName);
            SqlDataReader reader1 = command.ExecuteReader();
            if (reader1.Read())
            {
                string res = Convert.ToString(Convert.ToInt64(reader1[ID]) + 1);
                reader1.Close();
                return res;
            }
            else 
                return "";
        }
        private void Send_Order_Click(object sender, RoutedEventArgs e)
        {
            string s = "INSERT INTO [dbo].[PreOrder_2] " +
           "([id_PreOrder] ,[Start_location],[End_location],[Order_date],[End_date],[weight],[dimensions],[id_login]) " +
           "VALUES" +
           "(" + GetnextID("id_PreOrder", "PreOrder_2") + ", '" + Start_location.Text + "', '" + End_location.Text + "'" +
           ", '" + Start_date.Text + "', '" + End_date.Text + "', " + Weight_PreO.Text + "," + Dimensions_PreO.Text + "," + IDLogin+")";
            SqlDataAdapter adapter2 = new SqlDataAdapter(s, conn);
            r.AppendText("\n"+s);
            DataTable dt = new DataTable();
            adapter2.Fill(dt);
            SqlDataAdapter preorder2ndpage = new SqlDataAdapter("SELECT TOP(1000)[id_PreOrder],[Start_location],[End_location],[Order_date],[End_date],[weight],[dimensions],[id_login]FROM[logistic_services].[dbo].[PreOrder_2]", conn);
            DataSet dspreorder2 = new DataSet();
            preorder2ndpage.Fill(dspreorder2);
            StatusOrder_grid.ItemsSource = dspreorder2.Tables[0].DefaultView;
            PreOrder_grid.ItemsSource = dspreorder2.Tables[0].DefaultView;


        }
        private string ConvertDate(string s)
        {
            return "2022/2/2";
        }
        private void UpdateOrder_button_Click(object sender, RoutedEventArgs e)
        {
            DataGridRow row = (DataGridRow)StatusOrder_grid.ItemContainerGenerator.ContainerFromIndex(StatusOrder_grid.SelectedIndex);
            if (row != null)
            {
                TextBlock strloc = StatusOrder_grid.Columns[1].GetCellContent(row) as TextBlock;
                TextBlock ordDate = StatusOrder_grid.Columns[3].GetCellContent(row) as TextBlock;
                string cordDate = ConvertDate(ordDate.Text);
                TextBlock endloc = StatusOrder_grid.Columns[2].GetCellContent(row) as TextBlock;
                TextBlock weighT = StatusOrder_grid.Columns[5].GetCellContent(row) as TextBlock;
                TextBlock DimensionsT = StatusOrder_grid.Columns[6].GetCellContent(row) as TextBlock;
                TextBlock ClientT = StatusOrder_grid.Columns[7].GetCellContent(row) as TextBlock;

                //Data = tbl.Text;                
                string s = "INSERT INTO [dbo].[orders] ([id_order],[id_driver],[id_exauto],[id_cargo],[start_location],[ends_location],[distance],[order_date],[finish_date],[loaders],[price],[cost],[weight],[dimensions],[id_client],[id_manager],[id_statusorder])" +
            "VALUES" +
            "(" + GetnextID("id_order", "orders") +","+ Convert.ToString(DriverSelect_CB.SelectedIndex + 1) + ","+ Convert.ToString(CarSelect.SelectedIndex + 1) + "," + Convert.ToString(CargoSelect.SelectedIndex + 1) + ",\'" + strloc.Text + "\',\'" + endloc.Text + "\'," + distance.Text + ",\'" + cordDate + "\',\'" + Finishdate.Text + "\'," + loaderscount.Text + "," + priceTB.Text + "," + costTB.Text + "," + weighT.Text + "," + DimensionsT.Text + "," + ClientT.Text + "," + IDLogin + "," + Convert.ToString(StatusOrder_CB.SelectedIndex+1) + ")";
                SqlDataAdapter adapter3 = new SqlDataAdapter(s, conn);
                DataTable dt = new DataTable();
                adapter3.Fill(dt);
                SqlDataAdapter order2ndpage = new SqlDataAdapter("SELECT TOP (1000) [id_order],[id_driver],[id_exauto],[id_cargo],[start_location],[ends_location],[distance],[order_date],[finish_date],[loaders],[price],[cost],[weight],[dimensions],[id_client],[id_manager],[id_statusorder] FROM [logistic_services].[dbo].[orders]", conn);
                DataSet dspreorder2 = new DataSet();
                order2ndpage.Fill(dspreorder2);
                ReadyOrder.ItemsSource = dspreorder2.Tables[0].DefaultView;

                TextBlock TB = StatusOrder_grid.Columns[0].GetCellContent(row) as TextBlock;
                string ss = "DELETE FROM PreOrder_2 WHERE id_PreOrder = " + TB.Text;
                SqlDataAdapter adapteR = new SqlDataAdapter(ss, conn);
                DataTable dataTable = new DataTable();
                adapteR.Fill(dataTable);
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter("SELECT TOP(1000)[id_PreOrder],[Start_location],[End_location],[Order_date],[End_date],[weight],[dimensions],[id_login] FROM[logistic_services].[dbo].[PreOrder_2]", conn);
                DataSet dataSet = new DataSet();
                sqlDataAdapter.Fill(dataSet);
                StatusOrder_grid.ItemsSource = dataSet.Tables[0].DefaultView;
                //r.AppendText("\n" + s);

            }            
            
            //DataTable dt = new DataTable();
            //adapter2.Fill(dt);
        }
    }
}
